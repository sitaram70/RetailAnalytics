# AI-Driven Retail Analytics Dashboard (CPU-only)
Streamlit + FastAPI app for retail KPIs, RFM segments, basket pairs, and forecasting. CPU-only.
## Quickstart
```bash
python -m venv .venv
# Windows: .\.venv\Scripts\Activate.ps1  |  macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/simulate_retail.py --out_dir data --start_date 2025-01-01 --days 120 --customers 500 --products 120 --stores 4
python src/preprocess_sales.py --transactions data/raw/transactions.csv --visits data/raw/visits.csv --out data/raw/daily_sales.csv
python src/train_models.py --transactions data/raw/transactions.csv --daily data/raw/daily_sales.csv --model_out models
uvicorn src.api:app --reload --port 8000
streamlit run streamlit_app/app.py
```
