#!/usr/bin/env python3
import argparse, pandas as pd
def preprocess(tx_csv, vis_csv, out_csv):
    tx=pd.read_csv(tx_csv, parse_dates=['date']); vs=pd.read_csv(vis_csv, parse_dates=['date'])
    daily = tx.groupby(tx['date'].dt.date).agg(revenue=('revenue','sum'), orders=('order_id','nunique'), units=('quantity','sum')).reset_index().rename(columns={'date':'date'})
    vd = vs.groupby('date', as_index=False)['visits'].sum(); daily = daily.merge(vd, on='date', how='left')
    daily['aov'] = daily['revenue']/daily['orders'].clip(lower=1); daily['conversion'] = daily['orders']/daily['visits'].clip(lower=1)
    daily.to_csv(out_csv, index=False); print('Wrote', out_csv)
if __name__=='__main__':
    import argparse; ap=argparse.ArgumentParser()
    ap.add_argument('--transactions', default='data/raw/transactions.csv'); ap.add_argument('--visits', default='data/raw/visits.csv'); ap.add_argument('--out', default='data/raw/daily_sales.csv')
    a=ap.parse_args(); preprocess(a.transactions, a.visits, a.out)
